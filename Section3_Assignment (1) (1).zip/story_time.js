
    // TODO: Create 4-String variables to introduce develop your story.
let introduction = 'Hello hero';
let task = 'we need you to protect us';
let danger = 'many of the monster kings servents are coming';
let surprise = 'is that the MONSTER KING';


// TODO: Create 3-integer variables to set the time period of your story or discuss other number elements.
let fire,katana = 100
let water,spear = 90 
let earth,bat = 95


// TODO: Create 1-Array variable to show a collection of items your character might have.
let enemys = [skeletons,wolves,vampires,demons];

// TODO: Create 1-Boolean variable to demonstrate a true or false scenario.
let boss,fight = hard


// TODO: Print your story to the console.




